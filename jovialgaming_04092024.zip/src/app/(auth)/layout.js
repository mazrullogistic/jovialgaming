import React from "react";

const Authlayout = ({ children }) => {
  return <> {children}</>;
};

export default Authlayout;
