export const HOST_API = process.env.NEXT_APP_HOST_API || "";
