import tw from "tailwind-styled-components";

const Container = tw.div`
max-w-[1760px]
  m-auto
  w-full
    `;
const ProfileQuestionMain{


}
export default Container;



